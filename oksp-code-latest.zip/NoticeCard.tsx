import type { Notice } from "@/data/sampleNotices";
import { getMatchGradeStyle } from "@/lib/noticeGrades";
import { hasReopenKeyword, isPastDueDate } from "@/lib/noticeVisibility";

type NoticeCardProps = {
  notice: Notice;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
};

export default function NoticeCard({ notice, isSaved, onToggleSave }: NoticeCardProps) {
  const gradeStyle = getMatchGradeStyle(notice.matchGrade);
  const isExpired = isPastDueDate(notice.deadline);
  const isReopen = isExpired && hasReopenKeyword(`${notice.title} ${notice.summary ?? ""}`);
  const budgetLabel =
    notice.budget && notice.budget !== "-" ? notice.budget : "\uBBF8\uACF5\uAC1C";

  return (
    <article className="rounded-2xl border border-[#E5E8EB] bg-white p-5 shadow-sm transition hover:shadow-md sm:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${gradeStyle.badge}`}
        >
          {notice.matchGrade}
        </span>
        <span className="rounded-full bg-[#F2F4F6] px-2.5 py-1 text-xs font-semibold text-[#4E5968]">
          {notice.fitScore}
          {"\uC810"}
        </span>
        {isReopen && (
          <span className="inline-flex items-center rounded-full bg-[#FFF4E0] px-2.5 py-1 text-xs font-semibold text-[#E68600] ring-1 ring-inset ring-[#FFE0A3]">
            {"\uC7AC\uACF5\uACE0\u00B7\uC5F0\uC7A5"}
          </span>
        )}
        {!isReopen && isExpired && (
          <span className="inline-flex items-center rounded-full bg-[#FFF0F0] px-2.5 py-1 text-xs font-semibold text-[#F04452] ring-1 ring-inset ring-[#FFD6D6]">
            {"\uB9C8\uAC10 \uC9C0\uB0A8"}
          </span>
        )}
      </div>

      <div className="mt-4 sm:mt-5">
        <h2 className="text-base font-bold leading-snug text-[#191F28] sm:text-lg">
          {notice.title}
        </h2>
        <p className="mt-1.5 text-sm text-[#6B7684]">{notice.agency}</p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {notice.relatedProducts.map((product) => (
          <span
            key={product}
            className="rounded-lg bg-[#E8F3FF] px-2.5 py-1 text-xs font-medium text-[#1B64DA]"
          >
            {product}
          </span>
        ))}
      </div>

      {notice.keywords.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {notice.keywords.map((keyword) => (
            <span
              key={keyword}
              className="rounded-md bg-[#F2F4F6] px-2 py-0.5 text-xs text-[#4E5968]"
            >
              {keyword}
            </span>
          ))}
        </div>
      )}

      {notice.summary && (
        <p className="mt-4 line-clamp-2 text-sm leading-relaxed text-[#4E5968]">
          {notice.summary}
        </p>
      )}

      <div className="mt-5 flex flex-col gap-3 border-t border-[#F2F4F6] pt-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-3 text-sm text-[#6B7684]">
          <span>
            {"\uB9C8\uAC10 "}
            <span className="font-semibold text-[#191F28]">{notice.deadline}</span>
          </span>
          <span className="hidden text-[#E5E8EB] sm:inline" aria-hidden>
            |
          </span>
          <span>
            {"\uC608\uC0B0 "}
            <span className="font-semibold text-[#191F28]">{budgetLabel}</span>
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          <a
            href={notice.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center rounded-xl bg-[#3182F6] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#1B64DA] active:scale-[0.98]"
          >
            {"\uACF5\uACE0 \uBCF4\uAE30"}
          </a>
          <button
            type="button"
            onClick={() => onToggleSave(notice.id)}
            className={`inline-flex items-center justify-center rounded-xl px-4 py-2.5 text-sm font-semibold transition active:scale-[0.98] ${
              isSaved
                ? "bg-[#FFF4E0] text-[#E68600] ring-1 ring-[#FFE0A3]"
                : "bg-white text-[#4E5968] ring-1 ring-[#E5E8EB] hover:bg-[#F9FAFB]"
            }`}
          >
            {isSaved ? "\uAD00\uC2EC \uD574\uC81C" : "\uAD00\uC2EC \uC800\uC7A5"}
          </button>
        </div>
      </div>
    </article>
  );
}
